//
//  ITSProductModelTests.m
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>
#import "ITSProductModel.h"

@interface ITSProductModel (Tests)

- (NSError*) parseProductListResponse:(id)response;

@end

@interface ITSProductModelTests : XCTestCase

@property (nonatomic) ITSProductModel *modelToTest;

@end

@implementation ITSProductModelTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    self.modelToTest = [[ITSProductModel alloc] init];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testParseProductListResponseForNilResponse {
    
    XCTAssertNotNil([self.modelToTest parseProductListResponse:nil]);
    
}

- (void)testParseProductListResponseForInvalidJson {
    id responseJson = @{@"result": @"10",
                        @"results" : @[@1, @2]};
    
    XCTAssertNotNil([self.modelToTest parseProductListResponse:responseJson]);

}

- (void)testParseProductListResponseForResultCountAsString {
    id responseJson = @{@"resultCount": @"10",
                        @"results" : @[@{@"trackName" : @"track 1",
                                         @"artworkUrl30" : @"http://apple.com/image1/30x30.jpg"},
                                       @{@"trackName" : @"track 2",
                                         @"artworkUrl30" : @"http://apple.com/image2/30x30.jpg"}
                                       ]};
    
    XCTAssertNotNil([self.modelToTest parseProductListResponse:responseJson]);

}

- (void)testParseProductListResponseForZeroResults {
    id responseJson = @{@"resultCount": @0,
                        @"results" : @[]};
    
    XCTAssertNotNil([self.modelToTest parseProductListResponse:responseJson]);
    
}

- (void)testParseProductListResponseForvalidresponse {
    id responseJson = @{@"resultCount": @10,
                        @"results" : @[@{@"trackName" : @"track 1",
                                         @"artworkUrl30" : @"http://apple.com/image1/30x30.jpg"},
                                       @{@"trackName" : @"track 2",
                                         @"artworkUrl30" : @"http://apple.com/image2/30x30.jpg"}
                                       ]};
    
    XCTAssertNil([self.modelToTest parseProductListResponse:responseJson]);
    
}

@end
