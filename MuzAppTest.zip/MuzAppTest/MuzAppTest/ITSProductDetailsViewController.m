//
//  ITSProductDetailsViewController.m
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import "ITSProductDetailsViewController.h"
#import "ITSProductDetailModel.h"

@interface ITSProductDetailsViewController ()
@property (nonatomic, weak) IBOutlet UIImageView *thumbImageView;
@property (nonatomic, weak) IBOutlet UILabel *nameLabel;
@property (nonatomic, weak) IBOutlet UILabel *priceLabel;
@property (nonatomic, weak) IBOutlet UITextView *descriptionTextView;

@property (nonatomic, strong) ITSProductDetailModel *dataModel;

@end

@implementation ITSProductDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataModel = [[ITSProductDetailModel alloc] init];
    self.view.backgroundColor = [UIColor colorWithRed:227.0f/255.0f green:240.0f/255.0f blue:244.0f/255.0f alpha:1];
    self.title = @"Detail";
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self updateUIWithData];
}

- (void) updateUIWithData {
    self.thumbImageView.image = [UIImage imageNamed:@"Image-placeholder"];
    self.nameLabel.text = self.chosenProduct.name;
    
    if (self.chosenProduct.price.integerValue > 0) {
        self.priceLabel.text = [NSString stringWithFormat:@"$%@", [self.chosenProduct.price stringValue]];

    }
    
    [self.dataModel getImageForProduct:self.chosenProduct.productId withUrl:self.chosenProduct.thumbImageUrl andCompletionBlock:^(UIImage *thumbImage) {
        
        if (thumbImage) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.thumbImageView.image = thumbImage;
            });
            
        }
    }];
    /*
    if (self.chosenProduct.longDescription.length > 0) {
        self.descriptionTextView.text = self.chosenProduct.longDescription;
        
    } else {
        self.descriptionTextView.text = @"No description available.";
        
    }
     */
    NSMutableString *myString = [[NSMutableString alloc] initWithString:@"Artist: "];
    [myString appendString:self.chosenProduct.artistName];
    [myString appendString:@"\n"];
    [myString appendString:@"Album: "];
    [myString appendString:self.chosenProduct.shortDescription];
    [myString appendString:@"\n"];
    [myString appendString:@"Genre: "];
    [myString appendString:self.chosenProduct.primaryGenreName];
    
    /*
    [myString appendString:@"\n"];
    [myString appendString:@"ReleaseDate: "];
    NSString *dataString=[[NSString alloc] initWithData:self.chosenProduct.releaseDate encoding:NSUTF8StringEncoding];
    [myString appendString:dataString];
    */
    
    self.descriptionTextView.text = myString;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
