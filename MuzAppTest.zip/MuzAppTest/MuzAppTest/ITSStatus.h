//
//  ITSStatus.h
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ITSStatus : NSObject

@property (nonatomic, assign) NSInteger statusCode;
@property (nonatomic, strong) NSString *statusMessage;

@end
