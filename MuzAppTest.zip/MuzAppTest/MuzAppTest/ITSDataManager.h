//
//  ITSDataManager.h
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITSProduct.h"

@interface ITSDataManager : NSObject

+(ITSDataManager *)sharedDataManager;

-(void)addProduct:(ITSProduct*)product;
-(NSArray *) getProductList;
-(void) resetProductList;
-(NSArray *) getEntitiesList;
-(NSString *)getValueForEntity:(NSString *)entityKey;

@end
