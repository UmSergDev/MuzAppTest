//
//  ITSProductDetailModel.h
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ITSProductDetailModel : NSObject

- (void) getImageForProduct:(NSString *)productId withUrl:(NSString *)imageUrl andCompletionBlock:(void(^)(UIImage *))completionBlock;

@end
