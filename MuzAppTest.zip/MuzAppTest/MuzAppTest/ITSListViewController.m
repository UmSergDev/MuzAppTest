//
//  ITSListViewController.m
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import "ITSListViewController.h"
#import "ITSProductModel.h"
#import "ITSDataManager.h"
#import "ITSProductTableViewCell.h"
#import "CDActivityIndicatorView.h"
#import "Constants.h"
#import "ITSProductDetailsViewController.h"

@interface ITSListViewController () {
    NSString *selectedEntity;
    NSInteger chosenProductIndex;
}

@property (nonatomic, strong) ITSProductModel *dataModel;
@property (nonatomic, weak) IBOutlet UITableView *productListTable;
@property (nonatomic, strong) UIPickerView *entityPickerView;
@property (nonatomic, strong) UIView *pickerContainerView;
@property (nonatomic, weak) IBOutlet UISearchBar *iTunesSearchBar;
@property (nonatomic, weak) IBOutlet CDActivityIndicatorView *activityIndicatorView;
@property (nonatomic, weak) IBOutlet UIButton *selectedEntityBtn;



@end

@implementation ITSListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
    self.dataModel = [[ITSProductModel alloc] init];
    self.productListTable.estimatedRowHeight = 100.0f;
    self.productListTable.rowHeight = UITableViewAutomaticDimension;
    
    [self uiSetup];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void) uiSetup {
    
    self.activityIndicatorView.hidden = YES;
    self.activityIndicatorView.fitFrame = YES;
    [self.activityIndicatorView stopAnimating];
    [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:51.0f/255.0f green:184.0f/255.0f blue:255.0f/255.0f alpha:1]];
    [self.navigationController.navigationBar setTranslucent:NO];
    UITextField *txfSearchField = [self.iTunesSearchBar valueForKey:@"_searchField"]; // To change search bar background color
    txfSearchField.backgroundColor = [UIColor colorWithRed:227.0f/255.0f green:240.0f/255.0f blue:244.0f/255.0f alpha:1];
    self.view.backgroundColor = [UIColor colorWithRed:227.0f/255.0f green:240.0f/255.0f blue:244.0f/255.0f alpha:1];
    self.productListTable.backgroundColor = [UIColor clearColor];
    
    [self.iTunesSearchBar setBackgroundColor:[UIColor clearColor]];
    [self.iTunesSearchBar setBackgroundImage:[UIImage new]];
    [self.iTunesSearchBar setTranslucent:YES];
    [self.selectedEntityBtn setTitle:@"All" forState:UIControlStateNormal];
}

- (IBAction)tappedOnKindButton:(id)sender {
    
    if ([self.iTunesSearchBar isFirstResponder]) {
        [self.iTunesSearchBar resignFirstResponder];
    }
    
    if (!self.pickerContainerView) {
        self.pickerContainerView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.view.frame) - 300.0f, CGRectGetWidth(self.view.frame), 300.0f)];
        UIToolbar *accessoryBar = [self getPickerToolBarWithLeftButtonTitle:@"Cancel" withMainTitle:@"Entity" andRightButtontitle:@"Done"];

        self.entityPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(accessoryBar.frame), CGRectGetWidth(self.view.frame), 300.0f)];
        self.entityPickerView.dataSource = self;
        self.entityPickerView.delegate = self;
        
        [self.pickerContainerView addSubview:accessoryBar];
        [self. pickerContainerView addSubview:self.entityPickerView];
        self.pickerContainerView.backgroundColor = [UIColor lightGrayColor];
        

    }

//    if (selectedEntity.length > 0) {
//        [self.entityPickerView selectRow:[self.dataModel.entitiesArray indexOfObject:selectedEntity] inComponent:0 animated:NO];
//    }
    [self.view addSubview:self.pickerContainerView];
}

- (UIToolbar*)getPickerToolBarWithLeftButtonTitle:(NSString*)leftButtonTitle withMainTitle:(NSString*)title andRightButtontitle:(NSString*)rightButttonTitle
{
    
    UIToolbar* keyBoardToolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    keyBoardToolbar.backgroundColor = [UIColor whiteColor];
    
    UIBarButtonItem* fieldTitleButton = [[UIBarButtonItem alloc] initWithTitle:title style:UIBarButtonItemStylePlain target:self action:nil];
    [fieldTitleButton setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys: [UIFont fontWithName:@"Helvetica-Regular" size:26.0], NSFontAttributeName,nil] forState:UIControlStateNormal];
    [fieldTitleButton setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor], NSForegroundColorAttributeName,nil]
                                    forState:UIControlStateNormal];
    [fieldTitleButton setEnabled:FALSE];
    keyBoardToolbar.items = [NSArray arrayWithObjects:
                             [[UIBarButtonItem alloc] initWithTitle:leftButtonTitle style:UIBarButtonItemStylePlain target:self action:@selector(tappedOnPickerToolbarLeftButton)],
                             [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                             fieldTitleButton,
                             [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                             [[UIBarButtonItem alloc] initWithTitle:rightButttonTitle style:UIBarButtonItemStylePlain target:self action:@selector(tappedOnPickerToolbarRightButton)],
                             nil];
    [keyBoardToolbar sizeToFit];
    return keyBoardToolbar;
}

- (void)tappedOnPickerToolbarLeftButton {
    [self.pickerContainerView removeFromSuperview];
        if (self.dataModel.chosenEntity.length > 0) {
            [self.entityPickerView selectRow:[self.dataModel.entitiesArray indexOfObject:self.dataModel.chosenEntity] inComponent:0 animated:NO];
        }

}

- (void)tappedOnPickerToolbarRightButton {
        [self.pickerContainerView removeFromSuperview];
    self.dataModel.chosenEntity = selectedEntity;
    
    if (selectedEntity.length) {
        [self.selectedEntityBtn setTitle:selectedEntity forState:UIControlStateNormal];

    }
}

- (void)showResponseWithStatus:(ITSStatus *)status {
    
    self.activityIndicatorView.hidden = YES;
    [self.activityIndicatorView stopAnimating];

    if(status.statusCode == successCode) {
        
        [self.productListTable reloadData];
        [self.productListTable scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        
    } else {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:status.statusMessage preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancelAction = [UIAlertAction
                                       actionWithTitle:@"Ok"
                                       style:UIAlertActionStyleCancel
                                       handler:^(UIAlertAction *action)
                                       {
                                           
                                       }];
        
        [alert addAction: cancelAction];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    ITSProductDetailsViewController *detailController = segue.destinationViewController;
    detailController.chosenProduct = self.dataModel.productListArray[chosenProductIndex];
    
}

#pragma mark - UISearchBarDelegate

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    [self tappedOnPickerToolbarLeftButton];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [searchBar resignFirstResponder];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        self.activityIndicatorView.hidden = NO;
        [self.activityIndicatorView startAnimating];
    });
   

    [self.dataModel retrieveProductList:searchBar.text withEntity:self.dataModel.chosenEntity andCompletionBlock:^(ITSStatus *status) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self showResponseWithStatus:status];
        });
    }];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataModel.productListArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ITSProductTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    ITSProduct *product = [[ITSProduct alloc]init];
    product = self.dataModel.productListArray[indexPath.row];
    cell.nameLabel.text = product.name;
    cell.artistName.text = product.artistName;
    
    cell.iconImageView.image = [UIImage imageNamed:@"Image-placeholder"];
    
    [self.dataModel getImageForProduct:product.productId withUrl:product.iconImageUrl andCompletionBlock:^(UIImage *iconImage) {
        
        if (iconImage) {
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.iconImageView.image = iconImage;
            });

        }

    }];
    if (product.shortDescription.length) {
        cell.productDescription.text = product.shortDescription;

    } else {
        cell.productDescription.text = @"No description Available";
    }


    if (product.price.integerValue > 0) {
        cell.priceLabel.text = [NSString stringWithFormat:@"$%@", [product.price stringValue]];
        
    }

    return cell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    chosenProductIndex = indexPath.row;
    
    [self performSegueWithIdentifier:@"ShowDetailIdentifier" sender:self];
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma mark - UIPickerViewDataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return self.dataModel.entitiesArray.count;
}

#pragma mark - UIPickerViewDelegate

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return self.dataModel.entitiesArray[row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    selectedEntity = self.dataModel.entitiesArray[row];

}

@end
