//
//  Constants.h
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#ifndef MuzAppTest_Constants_h
#define MuzAppTest_Constants_h

//urls
#define iTunesBaseURL @"https://itunes.apple.com/"
#define iTunesSearchAPI @"search"

//error code

#define noDataErrorCode 111
#define noNetworkErrorCode 440
#define successCode 0

//error message

#define noDataErrorMessage @"No search results to show. Please try with different keyword."
#define noNetworkErrorMessage @"Couldn't reach server. Please try again."
#define defaultErrorMessage @"The operation couldn’t be completed."
#define errorDomian @"ITSErrorDefault"

#endif

