//
//  Utility.m
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import "Utility.h"
#import "Constants.h"

@implementation Utility

+ (NSString *)getErrorMessageForErrorCode:(NSInteger)errorCode {
    
    NSString *errorMessage = defaultErrorMessage;
    
    switch (errorCode) {
        case noDataErrorCode:
            errorMessage = noDataErrorMessage;
            break;
        case noNetworkErrorCode:
            errorMessage = noNetworkErrorMessage;
            break;
            
        default:
            errorMessage = defaultErrorMessage;

            break;
    }
    
    return errorMessage;
}

@end
