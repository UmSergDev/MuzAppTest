//
//  ITSDataManager.m
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import "ITSDataManager.h"

@interface ITSDataManager()

@property (nonatomic, strong) NSMutableArray *productArray;
@property (nonatomic, strong) NSDictionary *entitiesDictionary;

@end

@implementation ITSDataManager

+(ITSDataManager *)sharedDataManager {
    static ITSDataManager *dataManager = nil;
    static dispatch_once_t dispatchOnce;
    
    dispatch_once(&dispatchOnce, ^{
        dataManager = [[ITSDataManager alloc] init];
        dataManager.productArray = [[NSMutableArray alloc] init];
        dataManager.entitiesDictionary = @{@"All" : @"all",
                                           @"Movie" : @"movie",
                                           @"Podcast" : @"podcast",
                                           @"Music" : @"music",
                                           @"MusicVideo" : @"musicVideo",
                                           @"Audiobook" : @"audiobook",
                                           @"Short Film" : @"shortFilm",
                                           @"Tv Show" : @"tvShow",
                                           @"Software" : @"software",
                                           @"ebook" : @"ebook"
                                           };
    });
    
    return dataManager;
}

-(void)addProduct:(ITSProduct*)product {
    [self.productArray addObject:product];
}

-(void) resetProductList {
    [self.productArray removeAllObjects];
}


-(NSArray*)getProductList {
    return self.productArray;
}

-(NSArray *) getEntitiesList {
    return [self.entitiesDictionary allKeys];
}

-(NSString *)getValueForEntity:(NSString *)entityKey {
    return self.entitiesDictionary[entityKey];
}

@end
