//
//  ITSProductModel.h
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ITSStatus.h"
#import "ITSProduct.h"

@interface ITSProductModel : NSObject

@property (nonatomic, strong) NSString *chosenEntity;
@property (nonatomic, strong, readonly) NSArray *productListArray;
@property (nonatomic, strong, readonly) NSArray *entitiesArray;

- (void) retrieveProductList:(NSString *)searchString withEntity:(NSString*)entity andCompletionBlock:(void(^)(ITSStatus *))completionBlock;
- (void) getImageForProduct:(NSString *)productId withUrl:(NSString *)imageUrl andCompletionBlock:(void(^)(UIImage *))completionBlock;

@end
