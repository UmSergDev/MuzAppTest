//
//  ITSProductModel.m
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import "ITSProductModel.h"
#import "Constants.h"
#import "ServiceManager.h"
#import "ITSProduct.h"
#import "ITSDataManager.h"
#import "ITSStatus.h"
#import "Utility.h"

@interface ITSProductModel()

@property (nonatomic, strong) ServiceManager *serviceManager;

@end

@implementation ITSProductModel

-(id) init {
    
    self = [super init];

    if (self) {
        self.serviceManager = [[ServiceManager alloc] init];
    }
    
    return self;
}

- (void) retrieveProductList:(NSString *)searchString withEntity:(NSString*)entity andCompletionBlock:(void(^)(ITSStatus *))completionBlock {

    NSString *urlString;
    
    if (entity.length > 0 && ![entity isEqualToString:@"All"]) {
        urlString = [NSString stringWithFormat:@"%@%@?term=%@&entity=%@", iTunesBaseURL, iTunesSearchAPI, searchString, [[ITSDataManager sharedDataManager] getValueForEntity:entity]];
    } else {
        urlString = [NSString stringWithFormat:@"%@%@?term=%@", iTunesBaseURL, iTunesSearchAPI, searchString];

    }
    
    ITSStatus *status = [[ITSStatus alloc] init];
    
    [self.serviceManager getDataFromUrl:[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] withSuccessCallBack:^(id response) {
        NSError *parseError = [self parseProductListResponse:response];
        
        if (parseError) {
            status.statusCode = parseError.code;
            status.statusMessage = [Utility getErrorMessageForErrorCode:parseError.code];
        } else {
            status.statusCode = 0;
        }
        
        completionBlock (status);
        
    } andFailureCallBack:^(NSError *error) {
        status.statusCode = error.code;

        status.statusMessage = [Utility getErrorMessageForErrorCode:error.code];
        completionBlock (status);
    }];
}

- (NSError*) parseProductListResponse:(id)response {
    
    NSError *error = nil;
    
    if([response isKindOfClass:[NSDictionary class]] &&
       [response[@"resultCount"] isKindOfClass:[NSNumber class]] &&
       [response[@"resultCount"] intValue] > 0 &&
       [response[@"results"] isKindOfClass:[NSArray class]]) {
        
        ITSDataManager *dataManager = [ITSDataManager sharedDataManager];
        [dataManager resetProductList];
            NSArray *productList = response[@"results"];
            
            for(NSDictionary *productDict in productList) {
                ITSProduct *product = [[ITSProduct alloc] init];
                product.productId = [productDict[@"trackId"] stringValue];
                product.name = productDict[@"trackName"];
                product.iconImageUrl = productDict[@"artworkUrl30"];
                product.thumbImageUrl = productDict[@"artworkUrl100"];
                product.price = productDict[@"trackPrice"];
                product.shortDescription = productDict[@"collectionName"];
                product.artistName = productDict[@"artistName"];
                product.primaryGenreName = productDict[@"primaryGenreName"];
                product.primaryGenreName = productDict[@"releaseDate"];
                /*
                if (productDict[@"shortDescription"]) {
                    product.shortDescription = productDict[@"shortDescription"];
                } else if (productDict[@"description"]) {
                    product.shortDescription = productDict[@"description"];

                }
                
                if (productDict[@"longDescription"]) {
                    product.longDescription = productDict[@"longDescription"];
                } else if (productDict[@"description"]) {
                    product.longDescription = productDict[@"description"];
                    
                }
                 */
                
                [dataManager addProduct:product];
            }
        
    } else {
        error = [NSError errorWithDomain:errorDomian code:noDataErrorCode userInfo:@{@"errorMessage" : noDataErrorMessage}];
    }
    
    return error;
}

- (void) getImageForProduct:(NSString *)productId withUrl:(NSString *)imageUrl andCompletionBlock:(void(^)(UIImage *))completionBlock {
    
    NSArray *pathsArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSMutableString *path = [pathsArray firstObject];
    NSString *imageName = [NSString stringWithFormat:@"/%@_%@", productId, [imageUrl lastPathComponent]];
    NSString *imagePath = [path stringByAppendingString:imageName];
    UIImage *downloadedImage;
    
    // if image is already there don't download
    if ([[NSFileManager defaultManager] fileExistsAtPath:imagePath]) {
        downloadedImage = [UIImage imageWithContentsOfFile:imagePath];
        completionBlock (downloadedImage);
    } else {
        [self.serviceManager downloadImage:imageUrl withSuccessCallBack:^(NSURL* location) {

            NSData *imageData = [NSData dataWithContentsOfURL:location];
            [imageData writeToFile:imagePath atomically:YES];
            UIImage *downloadedImage = [UIImage imageWithData:
                                        [NSData dataWithContentsOfURL:location]];
            completionBlock(downloadedImage);
            
        } andFailureCallBack:^(NSError *error) {
            completionBlock(nil);
        }];

    }
}

-(NSArray *)productListArray {
    return [[ITSDataManager sharedDataManager] getProductList];
}

-(NSArray *)entitiesArray {
    return [[ITSDataManager sharedDataManager] getEntitiesList];
}

@end
