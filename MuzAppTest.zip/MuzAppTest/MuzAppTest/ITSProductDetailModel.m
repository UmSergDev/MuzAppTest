//
//  ITSProductDetailModel.m
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import "ITSProductDetailModel.h"
#import "ServiceManager.h"
#import "ITSDataManager.h"

@interface ITSProductDetailModel()

@property (nonatomic, strong) ServiceManager *serviceManager;

@end

@implementation ITSProductDetailModel

-(id) init {
    
    self = [super init];
    
    if (self) {
        self.serviceManager = [[ServiceManager alloc] init];
    }
    
    return self;
}

- (void) getImageForProduct:(NSString *)productId withUrl:(NSString *)imageUrl andCompletionBlock:(void(^)(UIImage *))completionBlock {
    NSArray *pathsArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSMutableString *path = [pathsArray firstObject];
    NSString *imageName = [NSString stringWithFormat:@"/%@_%@", productId, [imageUrl lastPathComponent]];
    NSString *imagePath = [path stringByAppendingString:imageName];
    UIImage *downloadedImage;
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:imagePath]) {
        downloadedImage = [UIImage imageWithContentsOfFile:imagePath];
        completionBlock (downloadedImage);
    } else {
        [self.serviceManager downloadImage:imageUrl withSuccessCallBack:^(NSURL* location) {
            
            NSData *imageData = [NSData dataWithContentsOfURL:location];
            [imageData writeToFile:imagePath atomically:YES];
            UIImage *downloadedImage = [UIImage imageWithData:
                                        [NSData dataWithContentsOfURL:location]];
            completionBlock(downloadedImage);
        } andFailureCallBack:^(NSError *error) {
            completionBlock(nil);
        }];
        
    }
}

@end
