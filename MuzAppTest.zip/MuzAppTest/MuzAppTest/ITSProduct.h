//
//  ITSProduct.h
//  MuzAppTest
//
///  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ITSProduct : NSObject

@property (nonatomic, strong) NSString *productId;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *shortDescription;
@property (nonatomic, strong) NSString *longDescription;
@property (nonatomic, strong) NSString *iconImageUrl;
@property (nonatomic, strong) NSString *thumbImageUrl;
@property (nonatomic, strong) NSNumber *price;
@property (nonatomic, strong) NSString *artistName;
@property (nonatomic, strong) NSString *primaryGenreName;
@property (nonatomic, strong) NSDate *releaseDate;

@end
