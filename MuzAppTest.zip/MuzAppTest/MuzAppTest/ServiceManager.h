//
//  ServiceManager.h
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ServiceManager : NSObject


- (void) getDataFromUrl:(NSString *)urlString withSuccessCallBack:(void(^) (id))successBlock andFailureCallBack:(void(^) (NSError *))failureBlock;
- (void) downloadImage:(NSString *)imageUrl withSuccessCallBack:(void(^) (NSURL *))successBlock andFailureCallBack:(void(^) (NSError *))failureBlock;

@end
