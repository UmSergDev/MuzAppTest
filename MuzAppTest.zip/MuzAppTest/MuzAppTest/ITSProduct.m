//
//  ITSProduct.m
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import "ITSProduct.h"

@implementation ITSProduct

@end
