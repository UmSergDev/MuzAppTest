//
//  ServiceManager.m
//  MuzAppTest
//
//  Created by Umarov Sergey on 13/01/17.
//  Copyright (c) 2017 Umarov Sergey. All rights reserved.
//

#import "ServiceManager.h"
#import "Reachability.h"
#import "Constants.h"

@implementation ServiceManager

- (void) getDataFromUrl:(NSString *)urlString withSuccessCallBack:(void(^) (id))successBlock andFailureCallBack:(void(^) (NSError *))failureBlock{
    
    if ([[Reachability reachabilityForInternetConnection] currentReachabilityStatus] != NotReachable ) {
        
        NSURLSessionConfiguration *sessionConfig = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *session = [NSURLSession sessionWithConfiguration:sessionConfig];
        
        NSURLRequest *request = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:urlString]];
        NSURLSessionTask *dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            
            if (error) {
                
                failureBlock (error);
                
            } else {
                
                NSError *jsonError;
                id jsonResponse = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&jsonError];
                
                successBlock(jsonResponse);
                
            }
            
        }];
        
        [dataTask resume];
    } else {
        
        NSError *error = [NSError errorWithDomain:errorDomian code:noNetworkErrorCode userInfo:@{@"errorMessage" : noNetworkErrorMessage}];
        
        failureBlock(error);
    }
    
    

}

- (void) downloadImage:(NSString *)imageUrl withSuccessCallBack:(void(^) (NSURL *))successBlock andFailureCallBack:(void(^) (NSError *))failureBlock {

    if ([[Reachability reachabilityForInternetConnection] currentReachabilityStatus] != NotReachable ) {
        NSURLSessionConfiguration *sessionConfig = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *session = [NSURLSession sessionWithConfiguration:sessionConfig];
        
        NSURLRequest *request = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:imageUrl]];
        
        NSURLSessionTask *downloadTask = [session downloadTaskWithRequest:request completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
            if (error) {
                
                failureBlock (error);
                
            } else {
                
                successBlock(location);
                
            }
            
        }];
        
        [downloadTask resume];
        
    } else {
        
        NSError *error = [NSError errorWithDomain:errorDomian code:noNetworkErrorCode userInfo:@{@"errorMessage" : noNetworkErrorMessage}];
        
        failureBlock(error);
    }

}



@end
